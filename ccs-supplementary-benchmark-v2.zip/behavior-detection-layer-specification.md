# Behavior Detection Layer Specification

**Version:** 1.0  
**Date:** 2026-11-08  
**Status:** Draft for Implementation  
**Author:** Correctover Research Team

---

## Executive Summary

This document specifies the acceptance criteria and implementation roadmap for the Behavior Detection Layer (BDL), a runtime security enhancement that addresses the 33.3% evasion vulnerability discovered in description obfuscation testing.

**Current state:** Text-based risk scoring achieves 83.44% attack block rate on original descriptions, but drops to 66.7% when descriptions are obfuscated (33.3% evasion success).

**Target state:** BDL must close this gap while maintaining or improving original-description performance and staying within latency budgets.

---

## 1. Acceptance Criteria (Hard Lines)

The Behavior Detection Layer MUST meet all three of the following criteria before deployment. These are non-negotiable acceptance thresholds.

### 1.1 Obfuscated Description Block Rate

**Target:** ≥ 85% (up from current 66.7%)

**Measurement:** Run the description obfuscation test (Section 2.4 of technical report v2) on 30 high-risk tools. The BDL must block at least 25.5 tools (85% of 30) even when descriptions are rewritten to remove dangerous keywords.

**Rationale:** The current 66.7% block rate on obfuscated descriptions means 10/30 tools evade detection. This is unacceptable for production deployment. The BDL must detect dangerous behavior regardless of how the tool describes itself.

### 1.2 Original Description Block Rate

**Target:** ≥ 83.44% (maintain current performance)

**Measurement:** Run the standard attack benchmark (Section 3.3 of technical report v2) on 163 attack calls with original descriptions. The BDL must block at least 136 calls (83.44% of 163), matching or exceeding current performance.

**Rationale:** Adding behavior detection must not degrade existing text-matching performance. If the BDL introduces false negatives on original descriptions, it fails acceptance.

### 1.3 Latency Budget

**Target:** P50 ≤ 200 microseconds (up from current 53.5µs)

**Measurement:** Run the full benchmark suite (1,092 calls) and measure P50 decision latency. The BDL adds computational overhead for behavior observation and analysis; this overhead must not exceed 146.5µs (200µs - 53.5µs baseline).

**Rationale:** 200µs is still negligible compared to tool execution times (seconds to minutes) and LLM inference latency (hundreds of milliseconds). This budget gives the BDL room to implement parameter-level analysis and session-level sequence detection without breaking the user experience.

---

## 2. Implementation Phases

### Phase 1: Parameter-Level Rules (Weeks 1-4)

**Goal:** Detect dangerous parameter patterns regardless of tool description.

**Approach:**
- Analyze tool call arguments for dangerous patterns:
  - File paths containing `/etc/passwd`, `/etc/shadow`, `~/.ssh/`, credential files
  - Network destinations matching known malicious IPs or data exfiltration endpoints
  - Shell commands containing `rm -rf`, `curl | bash`, `wget | sh`, privilege escalation
  - SQL queries containing `DROP TABLE`, `DELETE FROM`, `UNION SELECT`
- Maintain a parameter pattern database (separate from description keywords)
- Score tools based on argument content, not just description text

**Expected impact:**
- Catches tools with benign descriptions but dangerous arguments
- Reduces obfuscation evasion from 33.3% to ~15%
- Adds ~20-50µs to P50 latency

**Acceptance test:**
- Run obfuscation test with parameter rules enabled
- Measure evasion rate reduction
- Verify P50 latency stays under 100µs

### Phase 2: Session-Level Sequence Detection (Weeks 5-8)

**Goal:** Detect multi-step attack patterns across tool call sequences.

**Approach:**
- Track tool call sequences within each agent session
- Define dangerous sequence patterns:
  - Credential access → network upload (data exfiltration)
  - File read → file write to different location (lateral movement)
  - Shell command → privilege escalation → network access (full compromise chain)
  - Multiple failed attempts → successful attempt (brute force)
- Use sliding window analysis (last N calls in session)
- Maintain session state in memory (not persisted to disk for performance)

**Expected impact:**
- Catches attacks that decompose dangerous operations into individually-benign calls
- Reduces multi-step evasion success from 2% to <1%
- Adds ~50-100µs to P50 latency

**Acceptance test:**
- Run multi-step attack benchmark (50 sessions)
- Measure session-level detection rate
- Verify P50 latency stays under 150µs

### Phase 3: Sandboxed Execution (Weeks 9-16, Optional)

**Goal:** Execute high-risk tools in isolated environments to observe actual behavior.

**Approach:**
- For tools graded D or F, execute in a sandboxed container
- Monitor system calls, network connections, file access
- Compare observed behavior against declared capabilities
- Block tools that exhibit behavior inconsistent with their description

**Expected impact:**
- Catches tools that lie about their capabilities
- Reduces description-based evasion to near-zero
- Adds ~100-500µs to P50 latency (depending on sandbox overhead)

**Acceptance test:**
- Run full benchmark with sandboxed execution
- Measure detection rate and latency
- Verify P50 latency stays under 200µs

**Note:** Phase 3 is optional and depends on whether Phases 1-2 meet acceptance criteria. If Phases 1-2 achieve ≥85% obfuscation block rate and ≤200µs P50 latency, Phase 3 may be deferred.

---

## 3. Measurement Methodology

### 3.1 Obfuscation Test

**Input:** 30 high-risk tools (all grade F, risk scores 80-100)

**Procedure:**
1. Run each tool with original description → record decision
2. Obfuscate description (replace dangerous keywords with benign synonyms)
3. Run each tool with obfuscated description → record decision
4. Calculate block rate: (blocked / 30) × 100%

**Success criterion:** Block rate ≥ 85% (25.5/30 tools blocked)

### 3.2 Original Description Test

**Input:** 163 attack calls from 50 attack sessions

**Procedure:**
1. Run all 163 calls with original descriptions
2. Calculate block rate: (blocked / 163) × 100%

**Success criterion:** Block rate ≥ 83.44% (136/163 calls blocked)

### 3.3 Latency Test

**Input:** 1,092 tool calls from full benchmark suite

**Procedure:**
1. Run all 1,092 calls through BDL
2. Measure decision latency for each call
3. Calculate P50, P95, P99 latency

**Success criterion:** P50 ≤ 200 microseconds

---

## 4. Risk Mitigation

### 4.1 False Positive Management

**Risk:** BDL may block legitimate tools that happen to use dangerous parameters in safe contexts.

**Mitigation:**
- Implement an "escalate" decision (in addition to allow/deny) for borderline cases
- Require human review for escalated decisions
- Track false positive rate; if >5%, tighten parameter rules

### 4.2 Performance Regression

**Risk:** BDL may exceed latency budget, degrading user experience.

**Mitigation:**
- Profile each phase independently before integration
- Implement BDL as optional middleware (can be disabled if latency exceeds threshold)
- Optimize hot paths (parameter matching, sequence tracking) for speed

### 4.3 Evasion Adaptation

**Risk:** Attackers may adapt to BDL by avoiding known parameter patterns.

**Mitigation:**
- Treat BDL as one layer in a defense-in-depth strategy
- Combine with text-matching (current system) and CCS receipt auditing
- Monitor for new evasion patterns and update parameter rules accordingly

---

## 5. Success Metrics

### 5.1 Primary Metrics (Acceptance Criteria)

| Metric | Current | Target | Measurement |
|--------|---------|--------|-------------|
| Obfuscated block rate | 66.7% | ≥ 85% | 30-tool obfuscation test |
| Original block rate | 83.44% | ≥ 83.44% | 163-call attack benchmark |
| P50 latency | 53.5µs | ≤ 200µs | 1,092-call full benchmark |

### 5.2 Secondary Metrics (Monitoring)

| Metric | Current | Target | Measurement |
|--------|---------|--------|-------------|
| Multi-step detection rate | 98.0% | ≥ 98.0% | 50-session attack benchmark |
| False positive rate | 0.0% | ≤ 5.0% | 20-task benign benchmark |
| CCS receipt verification | 100% | 100% | 50-receipt sample |

### 5.3 Business Metrics (Post-Deployment)

| Metric | Target | Measurement |
|--------|--------|-------------|
| Customer adoption rate | ≥ 50% of existing customers | Monthly active users |
| Attack block rate (production) | ≥ 80% | Real-world attack attempts |
| Mean time to detect (MTTD) | ≤ 5 minutes | From attack start to block |
| Mean time to respond (MTTR) | ≤ 1 minute | From detection to containment |

---

## 6. Timeline

| Phase | Duration | Deliverable | Acceptance Test |
|-------|----------|-------------|-----------------|
| Phase 1: Parameter rules | Weeks 1-4 | Parameter pattern database, matching engine | Obfuscation test ≥ 75% |
| Phase 2: Sequence detection | Weeks 5-8 | Session tracker, sequence pattern engine | Multi-step detection ≥ 99% |
| Phase 3: Sandboxed execution | Weeks 9-16 | Sandbox orchestrator, behavior monitor | Full acceptance criteria |
| Integration & testing | Weeks 17-20 | BDL integrated with RuntimeGuard | All three hard lines met |
| Production deployment | Weeks 21-24 | BDL enabled for all customers | Business metrics on track |

**Total timeline:** 24 weeks (6 months)

---

## 7. Resource Requirements

### 7.1 Engineering

- 2 backend engineers (Phases 1-2)
- 1 systems engineer (Phase 3, sandbox infrastructure)
- 1 security researcher (threat modeling, pattern definition)
- 0.5 QA engineer (acceptance testing, benchmark automation)

### 7.2 Infrastructure

- Sandbox cluster: 10-20 containers for Phase 3 testing
- Benchmark automation: CI/CD pipeline for continuous acceptance testing
- Monitoring: Latency and detection rate dashboards

### 7.3 Budget

- Engineering cost: ~$300K (6 months, 4.5 FTE)
- Infrastructure cost: ~$50K (sandbox cluster, monitoring)
- **Total: ~$350K**

---

## 8. Decision Points

### 8.1 After Phase 1 (Week 4)

**Decision:** Proceed to Phase 2, or iterate on Phase 1?

**Criteria:**
- If obfuscated block rate ≥ 75%: proceed to Phase 2
- If obfuscated block rate < 75%: iterate on parameter rules for 2 more weeks

### 8.2 After Phase 2 (Week 8)

**Decision:** Proceed to Phase 3, or skip Phase 3?

**Criteria:**
- If all three hard lines met without Phase 3: skip Phase 3, proceed to integration
- If any hard line not met: proceed to Phase 3

### 8.3 After Phase 3 (Week 16)

**Decision:** Deploy to production, or iterate?

**Criteria:**
- If all three hard lines met: proceed to integration and deployment
- If any hard line not met: iterate on Phase 3 for 4 more weeks

---

## 9. Conclusion

The Behavior Detection Layer addresses a critical vulnerability in the current text-based risk scoring system. By implementing parameter-level rules, session-level sequence detection, and (optionally) sandboxed execution, we can close the 33.3% evasion gap while maintaining or improving existing performance.

The three hard acceptance criteria (≥85% obfuscated block rate, ≥83.44% original block rate, ≤200µs P50 latency) ensure that the BDL delivers measurable security improvements without degrading user experience.

This specification provides a clear roadmap for implementation, with defined phases, success metrics, and decision points. The 24-week timeline is aggressive but achievable with dedicated engineering resources.

**Next step:** Begin Phase 1 (parameter-level rules) immediately.

---

**End of Specification**
