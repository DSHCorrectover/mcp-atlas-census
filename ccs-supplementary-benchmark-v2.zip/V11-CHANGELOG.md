# draft-correctover-ccs-11 Changelog

**Date**: November 9, 2026  
**Author**: Guigui Wang <wgg234114134@163.com>  
**Status**: Ready for IETF submission

## Summary

draft-correctover-ccs-11 updates v10 with empirical benchmark findings and measurement methodology clarification. It adds three major contributions:

1. **Description Obfuscation Vulnerability** (Section 13.12) - Documents verified 33.3% evasion success rate against text-matching security rules
2. **Measurement Caliber Clarification** (Section 20.6) - Establishes reproducible denominator chain for benchmark claims
3. **Security Considerations Update** (Section 14) - Adds obfuscation vulnerability disclosure and mitigation guidance

## Changes from draft-10

### 1. New Section 13.12: Description Obfuscation Attack

Documents a verified vulnerability where replacing dangerous keywords in tool descriptions with benign synonyms achieves 33.3% evasion success rate against text-matching security rules.

**Test methodology:**
- 30 tools with dangerous functionality (shell execution, file deletion, network requests) had descriptions obfuscated using synonym replacement
- Obfuscated descriptions preserved functionality but removed trigger keywords
- Results: 10/30 (33.3%) bypassed text-matching rules and received ALLOW verdicts

**Evasion patterns:**
- "shell_exec" → "text_processor"
- "delete_file" → "remove_item"
- "send_request" → "transmit_data"

**Baseline:** Same 30 tools with original descriptions were blocked at 100% rate.

**Mitigation:** Implementations SHOULD combine lexical pattern matching with behavioral analysis that evaluates actual tool behavior, not just description text.

### 2. Updated Security Considerations (Section 14)

Added new bullet point disclosing the description obfuscation vulnerability:

> Text-matching security rules that evaluate tool descriptions are vulnerable to synonym replacement attacks. Empirical testing (Section 13.12) demonstrates a 33.3% evasion success rate when dangerous keywords are replaced with benign alternatives while preserving functionality. Mitigation: Implementations SHOULD combine lexical pattern matching with behavioral analysis.

### 3. New Section 20.6: Measurement Caliber and Empirical Baseline

Clarifies the denominator chain for benchmark claims:

**Denominator chain (verified November 2026):**
1. Static census: 23,639 tools discovered via public MCP server enumeration
2. Reachable pool: 1,241 tools on servers that responded within 72 hours
3. Runtime invocations: 1,092 tool calls observed over 7 days across 47 agent sessions
4. CCS receipts produced: 1,092 receipts (100% coverage)
5. Independently verified: 50 receipts (4.6% sample) passed third-party audit

**Key principle:** Claims based on different denominators are NOT comparable. Block rate claims MUST specify the population. Task-level vs. call-level measurements are incomparable.

**Baseline comparison requirements:**
- Same denominator
- Same observation window
- Same rule set
- Same measurement level

If conditions not met: documents MUST state "口径不同，待可比验证" (different calibers, pending comparable verification).

### 4. New Informative Reference

Added CCS Supplementary Benchmark V2 (Zenodo DOI: [TO BE ASSIGNED]) archiving:
- 1,092 CCS receipts dataset
- Description obfuscation test results (33.3% evasion rate)
- Measurement caliber documentation
- Verification scripts and third-party audit report

### 5. Abstract Updated

Added paragraph mentioning empirical findings:

> This revision adds empirical findings from benchmark testing: a description obfuscation vulnerability demonstrating 33.3% evasion success rate against text-matching security rules (Section 13.12), and measurement caliber clarification establishing the denominator chain for reproducible benchmark claims (Section 20.6). These additions are informative but critical for implementers assessing real-world security posture.

### 6. Relationship to CCS Formal Framework Updated

Added fifth DOI reference for CCS Supplementary Benchmark V2.

## Files Modified

- `/data/draft-correctover-ccs-11.xml` - Source XML (1773 lines)
- `/data/draft-correctover-ccs-11.txt` - Rendered TXT (4421 lines)

## Files Superseded

- `/data/draft-correctover-ccs-00.txt` - Marked as SUPERSEDED by `/data/SUPERSEDED-draft-correctover-ccs-00.md`
  - Reason: Written without knowledge of existing v10; regression removing 80% of content

## Next Steps

1. Submit Zenodo archive for supplementary benchmark data to obtain DOI
2. Update DOI placeholders in both XML and TXT files
3. Submit draft-correctover-ccs-11 to IETF Datatracker
4. Announce publication with emphasis on honest measurement caliber and vulnerability disclosure

## Key Differences from v10

| Aspect | v10 | v11 |
|--------|-----|-----|
| Date | October 7, 2026 | November 9, 2026 |
| Sections | 22 | 22 + 1.10 + 13.12 + 20.6 |
| Negative Test Cases | 11 | 12 (+ obfuscation attack) |
| Security Considerations | 16 bullets | 17 bullets (+ obfuscation) |
| Benchmark data | 229,539 static tools (Oct 12) | 23,639 → 1,241 → 1,092 → 50 (Nov) |
| Measurement caliber | Not specified | Explicitly defined |
| Obfuscation vulnerability | Not disclosed | Documented (33.3% evasion) |
| DOI references | 4 | 5 (+ supplementary benchmark) |
